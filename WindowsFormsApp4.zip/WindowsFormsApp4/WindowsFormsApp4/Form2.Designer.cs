﻿namespace WindowsFormsApp4
{
    partial class reportPenjualan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lreport = new System.Windows.Forms.Label();
            this.dgPenjualan = new System.Windows.Forms.DataGridView();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgPenjualan)).BeginInit();
            this.SuspendLayout();
            // 
            // lreport
            // 
            this.lreport.AutoSize = true;
            this.lreport.Font = new System.Drawing.Font("Tahoma", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lreport.Location = new System.Drawing.Point(610, 97);
            this.lreport.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lreport.Name = "lreport";
            this.lreport.Size = new System.Drawing.Size(454, 57);
            this.lreport.TabIndex = 0;
            this.lreport.Text = "REPORT PENJUALAN";
            // 
            // dgPenjualan
            // 
            this.dgPenjualan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPenjualan.Location = new System.Drawing.Point(1, 225);
            this.dgPenjualan.Name = "dgPenjualan";
            this.dgPenjualan.RowHeadersWidth = 51;
            this.dgPenjualan.Size = new System.Drawing.Size(1537, 720);
            this.dgPenjualan.TabIndex = 1;
            this.dgPenjualan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPenjualan_CellContentClick);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnBack.Location = new System.Drawing.Point(1393, 41);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 30);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // reportPenjualan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1540, 845);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.dgPenjualan);
            this.Controls.Add(this.lreport);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "reportPenjualan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Report Penjualan";
            this.Load += new System.EventHandler(this.reportPenjualan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgPenjualan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lreport;
        private System.Windows.Forms.DataGridView dgPenjualan;
        private System.Windows.Forms.Button btnBack;
    }
}